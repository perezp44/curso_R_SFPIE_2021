#- ejemplo de usar rowise para calcular % horizontales: 
#- vignette("rowwise")

browseVignettes(package = "dplyr") 
options(help_type = "html") 

library(tidyverse)

df <- tibble(id = 1:6, w = 10:15, x = 20:25, y = 30:35, z = 40:45)

rf <- df %>% rowwise(id)
rf %>% mutate(total = sum(c(w, x, y, z)))
rf %>% summarise(total = sum(c(w, x, y, z)))
rf %>% mutate(total = sum(c_across(where(is.numeric))))

#- para calcular porcentajes: primero calcula el total con rowise y luego aplica una formula ya por columnas

rf %>% mutate(total = sum(c_across(w:z))) %>% ungroup() %>% 
  mutate(across(w:z, ~ . / total))
