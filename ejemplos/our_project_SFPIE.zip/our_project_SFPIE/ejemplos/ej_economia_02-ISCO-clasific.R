#- pks para las clasificaciones ISCO: https://r-posts.com/labourr-1-0-0-automatic-coding-of-occupation-titles/


#- no lo acabo de ver terminado

library(labourR) #- install.packages("labourR")

corpus <- data.frame(  id = 1:3,
  text = c("Data Scientist", "Junior Architect Engineer", "Cashier at McDonald's"))


aa <- classify_occupation(corpus = corpus, isco_level = 3, lang = "en", num_leaves = 5)
aa_1 <- classify_occupation(corpus = corpus, isco_level = 1, lang = "en", num_leaves = 5)
