#- unsa slides: https://mkearney.github.io/nicar_tworkshop/#1

library(rtweet)
library(tidyverse)


#- un voluntario??
my_person <- ""

#- 3 important people ----------------------------------------------------------
my_person_vec <- c("hadleywickham", "NachoVegasTwit",  "bad_gyal_pussy")
usr <- lookup_users(my_person_vec)

#- 3 important people
my_person <- "hadleywickham"  #- @hadleywickham
my_person <- "bad_gyal_pussy" #- @bad_gyal_pussy
my_person <- "NachoVegasTwit" #- @NachoVegasTwit


#- quienes son tus seguidores??
followers <- get_followers(my_person, n = 100)   #- devuelve el user_id de los followers de un Twitter account

#- vamos aver detalles de los followers
followers_x  <- lookup_users(followers$user_id)    #- details of the followers
followers_xx <- followers_x %>% 
                 select(user_id, screen_name, location, description,  followers_count, friends_count,  hashtags, text)

#- A quien sigues?? se llaman friends
friend <- get_friends(my_person)
friend_x  <- lookup_users(friend$user_id)  #- details of the followers
friend_xx <- friend_x %>% select(user_id, screen_name, location, description,  followers_count, friends_count,  hashtags, text)

#- Vemos tus tweets, tu timeline -------
timeline <- get_timeline(my_person, n = 100)
ts_plot(timeline, "weeks")


#- tus favoritos -----
favorites <- get_favorites(my_person , n = 100)
ts_plot(favorites, "weeks")


#------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------

#- busca 100 tweets con un hastag
aa_tweets <- search_tweets("#rstats", n = 100, include_rts = FALSE)
aa_users <- search_users(q = "#rstats", n = 100, parse = TRUE)



#- search for multiple keywords
rt <- search_tweets(q = "rstats AND python", n = 120)
rt <- search_tweets("rstats", lang = "en", include_rts = FALSE)

#- busqueda georeferenciada
rt <- search_tweets("lang:es", geocode = lookup_coords("Valencia, Spain")) #- no funciona. API Google Maps



#- Get trends: Discover what’s currently trending in San Francisco.
sf <- get_trends("Valencia")



#- Se pueden mandar tweets directamente desde R
#post_tweet("Los sociologos son muy listos #sociologia")

#- https://twitter.com/romain_francois/status/1115531328479485952/photo/1

#- https://cran.r-project.org/web/packages/rtweet/vignettes/stream.html

