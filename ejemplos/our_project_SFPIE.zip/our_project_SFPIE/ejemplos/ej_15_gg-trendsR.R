#- https://martinctc.github.io/blog/vignette-google-trends-with-gtrendsr/
#- https://cran.r-project.org/web/packages/gtrendsR/index.html
#- https://github.com/PMassicotte/gtrendsR

library(tidyverse)
# install.packages("gtrendsR")
library(gtrendsR)

#- ayuda para el pkg gtrendsR
help(package = "gtrendsR")

categories <- categories
countries <- countries


search_terms <- c("ggplot2", "dplyr")
output_results <- gtrends(keyword = search_terms,
                           geo = "ES",
                           time = "today 12-m") 

#- veamos los resultados
plot(output_results)

output_results %>% summary()

output_results %>% .$interest_over_time %>% glimpse()

#---- 
df <- output_results[[3]]

df <- output_results[[1]]
class(df)
str(df)



#- el plot del post
df %>%
    ggplot(aes(x = date, y = hits)) +
    geom_line(colour = "darkblue", size = 1.5) +
    facet_wrap(~ keyword) +
    ggthemes::theme_economist() 

#- ahora grafico de todos los tópicos en el mismo plot
df %>%
    ggplot(aes(x = date, y = hits, color = keyword)) +
    geom_line(size = 1) 

