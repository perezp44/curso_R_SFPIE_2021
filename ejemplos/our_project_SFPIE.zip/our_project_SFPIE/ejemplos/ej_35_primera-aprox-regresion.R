#- ejemplo: primera aprox. a análisis de regresión


set.seed(1234) #- inicializo el generador de números aleatorios

#- genero 2 variables explicativas(X, regresores, predictores)
horas_estudio <- rnorm(n = 100, mean = 70, sd = 20)
inteligencia  <- rnorm(100, 80, 4)

#- genero el género de 100 personas
gender <- sample( c(1, 0), 100, replace = TRUE, prob = c(0.5, 0.5) )

#- v. dependiente (nota que obtienen los estudiantes en el examen)
nota_ex <- 0.5 + 2*horas_estudio + 0.00001*inteligencia + 4*gender + rnorm(100, 0, sd = 0.1)

#- agrupamos los datos en un data.frame
datos <- data.frame(nota_ex, horas_estudio, inteligencia, gender)
rm(nota_ex, horas_estudio, inteligencia, gender)

#- estimamos un modelo lineal
my_model <- lm( formula = nota_ex ~ horas_estudio + inteligencia + gender , data = datos)
summary(my_model)


#- pongamos algún efecto interacción: inteligencia*gender
my_model <- lm( formula = nota_ex ~ horas_estudio + inteligencia + gender + inteligencia*gender , data = datos)
summary(my_model)

#- https://www.datacamp.com/community/tutorials/linear-regression-R
#- http://r-statistics.co/Linear-Regression.html
#- https://tutorials.iq.harvard.edu/R/Rstatistics/Rstatistics.html#multilevel_modeling
#- https://www.statmethods.net/stats/regression.html


#-TAREA: cómo podriamos hacer un gráfico ilustrátivo del modelo que acabamos de estimar?
#-TAREA para casa: ¿podemos hacer alguna tabla más bonita?


