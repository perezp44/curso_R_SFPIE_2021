library(ggplot2)
iris <- iris

#- grafico con f. de densidad estimada geom_density()
ggplot(iris, aes(x = Sepal.Length)) + geom_density()
ggplot(iris, aes(x = Sepal.Length)) + geom_density() + facet_grid(. ~ Species)



ggplot(iris, aes(x = Sepal.Length)) + geom_density(aes(group = Species))

ggplot(iris, aes(x = Sepal.Length)) + geom_density(aes(group = Species, colour = Species, fill = Species), alpha = 0.3)



#- Joy Division plot
library(ggridges)
ggplot(iris, aes(x = Sepal.Length, y = Species)) + geom_density_ridges()


ggplot(iris, aes(x = Sepal.Length, y = Species)) + geom_density_ridges(aes(fill = Species))


#- otros 2 gráficos chulos
ggplot(data = mpg) +
  geom_boxplot(mapping = aes(x = reorder(class, hwy, FUN = median), y = hwy))
# instalar lvplot pkg  geom_lv()   devtools::install_github("lvplot/hadley")
# otro plo -----------------------------------------
ggplot(data = mpg) +
  geom_violin(mapping = aes(x = reorder(class, hwy, FUN = median), y = hwy)) +
  coord_flip()

# para hecr zoom
coord_cartesian(ylim = c(0, 20))

