#- DATOS COVID recopilación:

#- https://github.com/joachim-gassen/tidycovid19   (fantástico!!!)
library(tidycovid19)


#- cargamos datos covid de la Jhon Hopkins
url_de_los_datos <- "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_deaths_global.csv"

d <- readr::read_csv(url_de_los_datos)

#- el paquete covidregionaldata-------------------------------------------------
#- remotes::install_github("epiforecasts/covidregionaldata")
aa <- covidregionaldata::get_national_data()
bb <- covidregionaldata::get_regional_data(isocode = "ES")
library(tidyverse)
zz <- aa %>% distinct(country)


xx <-   covidregionaldata::get_interventions_data()   #- datos de intervenciones


#- otro paquete covid ---------------------------------------------------------
#- https://cran.r-project.org/web/packages/oxcovid19/index.html




#------------------------------- DATOS ESPAÑOLES ------------------------------------------
#- https://github.com/montera34/escovid19data
url_esp <- "https://raw.githubusercontent.com/montera34/escovid19data/master/data/output/covid19-provincias-spain_consolidated.csv"
df_esp <- readr::read_csv(url_esp)

#- https://cnecovid.isciii.es/
url_esp_2 <- "https://cnecovid.isciii.es/covid19/resources/datos_provincias.csv"
df_esp_2 <- readr::read_csv(url_esp_2)


#- comunitat: https://dadesobertes.gva.es/va/dataset?tags=COVID-19
url_CV <- "https://dadesobertes.gva.es/dataset/9a4c287a-7f07-4312-b0fd-91373ad32f6e/resource/69c32771-3d18-4654-8c3c-cb423fcfa652/download/covid-19-serie-de-personas-fallecidas-en-la-comunitat-valenciana.csv"
library(readr)
covid <- readr::read_delim(url_CV, delim = ";")
str(covid)

