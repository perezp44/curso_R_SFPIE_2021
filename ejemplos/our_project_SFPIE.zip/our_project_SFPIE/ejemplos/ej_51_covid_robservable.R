#- Vamos a hacer un race-barchart con datos covid
#- utilizaremos el pkg "robservable": https://cran.r-project.org/web/packages/robservable/index.html
#- con este pkg se pueden hacer algunas visualizaciones dinámicas: https://cran.r-project.org/web/packages/robservable/vignettes/gallery.html

library(tidyverse)
library(robservable)   #- install.packages("robservable")
library(wpp2019)       #- install.packages("wpp2019")


#- Load Covid-19 data from Johns Hopkins Github repository
#- Fíjate que no usa rio::import() , sino readr::read_csv()
url_de_los_datos <- "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_deaths_global.csv"

d <- readr::read_csv(url_de_los_datos)

#- Fíjate que los datos:
#- 1) tienen nombres raros, con caracteres especiales, por ejemplo en la v. Province/State Un poco más técnico, son nombres no sintácticos
#- 2) están en formato ANCHO: hay una columna para las observaciones de cada día
#- 3) Son datos de muertes covid acumulados
#- 4) Algunos países como "Australia" tienen los datos desagregdos por provincias. Otros como "Spain", no.

d_x <- d %>% filter(`Country/Region` %in% c("Australia", "Spain") )


#- arreglamos los datos -------
df <- d %>%
  select(-`Province/State`, -Lat, -Long) %>%    #- quitamos 3 columnas que no necesitamos. Fíjate en `Province/State`
  rename(id = `Country/Region`)   %>%           #- cambiamos un nombre rarito
  group_by(id) %>%                              #- agrupamos por "id", en realidad por país, bueno por Country/Region
  summarise(across(everything(), sum))     #- calculamos la suma (para q los países con regiones pasen a tener el total del país)


#- fíjate q ahora ya hay una sola fila para cada país
df_x <- df %>% filter(id %in% c("Australia", "Spain") )

#- los datos están en formato ANCHO: los pasamos a LONG
df <- df %>%     
  pivot_longer(-id, names_to = "date") %>%  #- fíjate como ha seleccionado las columnas para hacer pinot_longer, todas menos id
  mutate(date = as.character(lubridate::mdy(date))) #- date lo transforma primer a fecha (mdy) y luego a character


## Generate chart ----------------
robservable(
  "https://observablehq.com/@juba/bar-chart-race",
  include = c("viewof date", "chart", "draw", "styles"),
  hide = "draw",
  input = list(
    data = df,   #- usamos df -------------
    title = "COVID-19 deaths",
    subtitle = "Cumulative number of COVID-19 deaths by country",
    source = "Source : Johns Hopkins University"
  ),
  width = 700,
  height = 710
)

#- Esto lo que había en ele ejemplo en: https://cran.r-project.org/web/packages/robservable/vignettes/gallery.html
#- vamos a ver si podemos repetir el ejercicio, pero con datos per cápita ---------------------

#- world population de la ONU
library(wpp2019)   #-install.packages("wpp2019")
data(pop)  #- raro para cargar los datos


#- limpiamos el Global ----
objetos_no_borrar <- c("df", "pop")
rm(list = ls()[!ls() %in% objetos_no_borrar])


#- solo usaremos la población de 2020
pop <- pop %>% select(country_code, name, poblacion = `2020`)

#- quiero un data.frame con los países q hay en df (covid)
df_names <- df %>% distinct(id, .keep_all = TRUE)


#- vamos  a ver si podemos juntar pop y df usando los nombres de los países
zz_left <- left_join(pop, df_names, by = c("name" = "id"))     #- 249 filas (o países)

zz_anti_1 <- anti_join(pop, df_names, by = c("name" = "id"))   #- 88

zz_anti_2 <- anti_join(df_names, pop, by = c("id" = "name"))   #- 28


zz_full <- full_join(pop, df_names, by = c("name" = "id")) %>% 
           filter(is.na(poblacion) | is.na(date))

#- arreglemos algunos nombres de los paises en pop xq no coinciden con los nombres de los países en df
pop <- pop %>% mutate(name = ifelse(name == "Iran (Islamic Republic of)", "Iran", name))

pop <- pop %>% mutate(name = case_when(
                 name == "Bolivia (Plurinational State of)"     ~ "Bolivia",
                 name == "Venezuela (Bolivarian Republic of)"   ~  "Venezuela",
                 name == "Russian Federation"                   ~  "Russia",
                 name == "United States of America"             ~  "US",
                 TRUE  ~  name ))

#- limpiemos el Global 
rm(list = ls(pattern = "^zz_"))

#- fusionemos los 2 df's ------------------------------------------
df_ok <- left_join(df, pop, by = c("id" = "name"))

zz_malos <- df_ok %>% filter(is.na(poblacion)) %>% distinct(id)

#- creamos los casos covid per cápita
df_ok <- df_ok %>% mutate(value = (value/poblacion)*100.000 ) %>% select(id, date, value)




## Generate chart
robservable(
  "https://observablehq.com/@juba/bar-chart-race",
  include = c("viewof date", "chart", "draw", "styles"),
  hide = "draw",
  input = list(
    data = df_ok,   #- usamos df_ok
    title = "COVID-19 deaths",
    subtitle = "Cumulative number of COVID-19 deaths by country (per 100.000 inhabitants)",
    source = "Source : Johns Hopkins University"
  ),
  width = 700,
  height = 710
)


#- podría intentar incorporar códigos de continente para hacerlo para solo Europa

#- a ver con el pkg 
library(countrycode)
aa <- countrycode::codelist

#- aver con Gapminder

gapminder <- gapminder::gapminder %>% select(country, continent) %>% distinct()

zz_full <- left_join(df_names, gapminder, by = c("id" = "country"))


df_ok_2 <- left_join(df_ok, gapminder, by = c("id" = "country"))
df_ok_2 <- df_ok_2 %>% filter(continent == "Europe") %>% select(-continent)



## Generate chart
robservable(
  "https://observablehq.com/@juba/bar-chart-race",
  include = c("viewof date", "chart", "draw", "styles"),
  hide = "draw",
  input = list(
    data = df_ok_2,   #- usamos df_ok
    title = "COVID-19 deaths",
    subtitle = "Cumulative number of COVID-19 deaths by country (per 100.000 inhabitants)",
    source = "Source : Johns Hopkins University"
  ),
  width = 700,
  height = 710
)
