#- pues que el paquete >> library(covid19mobility)  tiene acceso facil a datos de movilidad covid por paises, por cuidades etc....

aa <- readr::read_csv("~/Escritorio/my_BIG-DATA_20-21/my_materiales_20-21/_a-mas-materiales/Global_Mobility_Report.csv")
library(tidyverse)
bb <- aa %>% dplyr::filter(country_region == "Spain")
cc <- bb %>% dplyr::filter(date == "2020-03-22")


#- isocodes: https://cran.r-project.org/web/packages/ISOcodes/ISOcodes.pdf


#- lo vi en este paquete y entonces vi que puedo descargar el informe de Google: https://cran.r-project.org/web/packages/covid19mobility/index.html


library(covid19mobility)
library(sf)
library(rnaturalearth)
library(dplyr)
library(ggplot2)

apple_cities <- refresh_covid19mobility_apple_city()
aa <- apple_cities %>% filter(country == "Spain") %>% distinct(location)

df_gg <- covid19mobility::covid19mobility_google_country_demo
df_ap <- covid19mobility::covid19mobility_apple_country_demo


# Get UN LOCODEs
# from jebyrnes/unlocode
locode_url <- "https://github.com/jebyrnes/unlocodeR/raw/master/data/unlocode.rda"
un <- rio::import(locode_url)
un_aa <- un %>% dplyr::filter(iso_3166_2_country == "ES")

f <- tempfile()
utils::download.file(locode_url, f, quiet = TRUE)
load(f) # loads unlocode
unlink(f)
