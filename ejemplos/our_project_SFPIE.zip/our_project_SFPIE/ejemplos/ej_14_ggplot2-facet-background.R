#- hace graficos con facet PERO mostrando en el backgroung el total de la distribucion (kara_woo)
#- graficos chulos: https://twitter.com/kara_woo/status/930135125345452032
#- https://drsimonj.svbtle.com/plotting-background-data-for-groups-with-ggplot2
#- https://yutani.rbind.io/post/2018-06-03-anatomy-of-gghighlight/  (parecido a lo de Kara woo)

library(ggplot2)

ggplot(iris, aes(x = Sepal.Width)) +  geom_histogram()

ggplot(iris, aes(x = Sepal.Width, fill = Species)) +  geom_histogram()

ggplot(iris, aes(x = Sepal.Width)) +  geom_histogram() + facet_wrap(~ Species)



#- ahora con facet PERO en el background toda la distribucion
d <- iris        # Full data set
d_bg <- d[, -5]  # Background Data - full without the 5th column (Species)
ggplot(d, aes(x = Sepal.Width)) +
  geom_histogram(data = d_bg, fill = "grey") +
  geom_histogram() +
  facet_wrap(~ Species)


#- lo mismo pero con colorines
d <- iris        # Full data set
d_bg <- d[, -5]  # Background Data - full without the 5th column (Species)
ggplot(d, aes(x = Sepal.Width, fill = Species)) +
  geom_histogram(data = d_bg, fill = "grey", alpha = .5) +
  geom_histogram(colour = "black") +
  facet_wrap(~ Species) +
  guides(fill = FALSE) +  # to remove the legend
  theme_bw()


#- Tb el truco del backgroung pero con geom_point()
ggplot(d, aes(x = Sepal.Width, y = Sepal.Length)) +
  geom_point(data = d_bg, colour = "grey") +
  geom_point() + 
  facet_wrap(~ Species)


#- lo mismo con color
ggplot(d, aes(x = Sepal.Width, y = Sepal.Length, colour = Species)) +
  geom_point(data = d_bg, colour = "grey", alpha = .2) +
  geom_point() + 
  facet_wrap(~ Species) +
  guides(colour = FALSE) +
  theme_bw()



# 
# #---------------------------------------- pseudo code
# ggplot(data = full_data_frame, aes(...)) +
#   geom_*(data = data_frame_without_grouping_var, colour/fill = "neutral_color") +
#   geom_*() +
#   facet_wrap(~ grouping_var)
