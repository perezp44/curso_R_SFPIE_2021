#- ejemplo covid ---------------------------------

library(tidyverse)
library(wpp2019)       #- install.packages("wpp2019") datos de la ONU: World Population Prospects 2019.

#- cargamos datos covid de la Jhon Hopkins
url_de_los_datos <- "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_deaths_global.csv"

d <- readr::read_csv(url_de_los_datos)

#- Fíjate que los datos:
#- 1) tienen nombres raros, con caracteres especiales, por ejemplo en la v. Province/State Un poco más técnico, son nombres no sintácticos
#- 2) están en formato ANCHO: hay una columna para las observaciones de cada día
#- 3) Son datos de muertes covid acumulados
#- 4) Algunos países como "Australia" tienen los datos desagregados por provincias. Otros como "Spain", no.

#- arreglamos los datos -------
df <- d %>%
  select(-`Province/State`, -Lat, -Long) %>%    #- quitamos 3 columnas que no necesitamos. 
  rename(id = `Country/Region`)   %>%           #- cambiamos un nombre rarito
  group_by(id) %>%                              #- agrupamos por "id", en realidad por país, 
  summarise(across(everything(), sum)) %>%      #- calculamos la suma (para los países con regiones)
  pivot_longer(-id, names_to = "date") %>%      #- pasamos a formato largo
  mutate(date = as.character(lubridate::mdy(date))) #- cambia el formato de la fecha


#- world population de la ONU
library(wpp2019)   #-install.packages("wpp2019")
data(pop)  #- raro para cargar los datos

#- limpiamos el Global ----
objetos_no_borrar <- c("df", "pop")
rm(list = ls()[!ls() %in% objetos_no_borrar])

#- solo usaremos la población de 2020
pop <- pop %>% select(country_code, name, poblacion = `2020`)

#- arreglemos algunos nombres de los países en pop xq no coinciden con los nombres de los países en df
pop <- pop %>% mutate(name = ifelse(name == "Iran (Islamic Republic of)", "Iran", name))

pop <- pop %>% mutate(name = case_when(
  name == "Bolivia (Plurinational State of)"     ~ "Bolivia",
  name == "Venezuela (Bolivarian Republic of)"   ~  "Venezuela",
  name == "Russian Federation"                   ~  "Russia",
  name == "United States of America"             ~  "US",
  TRUE  ~  name ))

#- limpiemos el Global 
rm(list = ls(pattern = "^zz_"))

#- fusionemos los 2 df's ------------------------------------------
df_ok <- left_join(df, pop, by = c("id" = "name"))

#- creamos los casos covid per cápita
df_ok <- df_ok %>% mutate(value_percapita = (value/poblacion)*100.000) 
df_ok <- df_ok %>% tidyr::drop_na(country_code)   #- quito los q no tienen country_code


#- podría intentar incorporar códigos de continente. Parece q los códigos país q usa la ONU son iso3n)
library(countrycode)
aa <- countrycode::codelist %>% select(iso3n, continent, iso.name.en, eurostat) %>% distinct() %>% mutate(iso3n = as.integer(iso3n))

df_paises <- left_join(df_ok, aa, by = c("country_code" = "iso3n"))

#- cambio algunos nombres y quito variables 
df_paises <- df_paises %>% rename(country = iso.name.en) %>%      #- cambio el nombre
                           select(-c(id, eurostat)) %>%           #- quito 2 variables
                           select(country, country_code, continent, date, everything())


#- limpiamos el Global ----
rm(list = setdiff(ls(), "df_paises"))

#- vemos cuando está peor cada país (por ejemplo ver el % de muertos respecto al máximo)

df_paises <- df_paises %>% arrange(country, date)  #- por si no estuviesen ordenados por fecha
df_paises <- df_paises %>% group_by(country, country_code) %>% mutate(value_1dia = value - lag(value)) %>% ungroup()


df_paises <- df_paises %>% group_by(country, country_code) %>% 
  mutate(max_value = max(value, na.rm = TRUE)) %>% 
  mutate(max_1dia = max(value_1dia, na.rm = TRUE)) %>% ungroup() 


zz <- df_paises %>% distinct(country, max_value, max_1dia)


#- https://github.com/joachim-gassen/tidycovid19   (fantástico!!!)
library(tidycovid19)




#------------------------------- DATOS ESPAÑOLES ------------------------------------------
#- https://github.com/montera34/escovid19data
url_esp <- "https://raw.githubusercontent.com/montera34/escovid19data/master/data/output/covid19-provincias-spain_consolidated.csv"
df_esp <- readr::read_csv(url_esp)

#- https://cnecovid.isciii.es/
url_esp_2 <- "https://cnecovid.isciii.es/covid19/resources/datos_provincias.csv"
df_esp_2 <- readr::read_csv(url_esp_2)


#- comunitat: https://dadesobertes.gva.es/va/dataset?tags=COVID-19
url_CV <- "https://dadesobertes.gva.es/dataset/9a4c287a-7f07-4312-b0fd-91373ad32f6e/resource/69c32771-3d18-4654-8c3c-cb423fcfa652/download/covid-19-serie-de-personas-fallecidas-en-la-comunitat-valenciana.csv"
library(readr)
covid <- readr::read_delim(url_CV, delim = ";")
str(covid)
     