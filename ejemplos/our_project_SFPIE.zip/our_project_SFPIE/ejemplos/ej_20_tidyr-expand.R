#- Es una funcion de tidyr q se usa para ver q categorias faltan en los datos
#- prueba crossing tidyr  http://tidyr.tidyverse.org/reference/expand.html   (quizas para tutorial NAs)
library(tidyverse) 
library(broom)
library(purrr)
# All possible combinations of vs & cyl, even those that aren't present in the data: http://tidyr.tidyverse.org/reference/expand.html
aa <- mtcars
bb <- expand(mtcars, vs, cyl)          #- All possible combinations of vs & cyl, even those that aren't present in the data
cc <- expand(mtcars, nesting(vs, cyl)) #- Only combinations of vs and cyl that appear in the data



df <- tibble(
  year   = c(2010, 2010, 2010, 2010, 2012, 2012, 2012),
  qtr    = c(   1,    2,    3,    4,    1,    2,    3),
  return = rnorm(7)
)
df %>% expand(year, qtr)           #- todas las combinaciones de esas variables
df %>% complete(year , qtr)        #- el df original con todas las combinaciones posibles de year y qtr (pero se queda todas las columnas del df)


df %>% expand(nesting(year, qtr))  #- solo las combinaciones presentes en los datos

