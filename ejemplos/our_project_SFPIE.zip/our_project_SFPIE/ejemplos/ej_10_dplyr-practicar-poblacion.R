#- Objetivo: practicar importación y manejo de datos con tidyverse
library(tidyverse)

#- utilizaremos datos de población del Padron del INE 1996-2019
#- devtools::install_github("perezp44/pjpv2020.01")
df <- pjpv.datos.01::pob_muni_1996_2020


#- mirando los datos
str(df)
skimr::skim(df)   #- https://github.com/ropenscilabs/skimr

# visdat::vis_dat(df, warn_large_data = FALSE)    #- como no hay NA's , aqui esto no es muy util (pero puede sernos útil con otros dfs)
# visdat::vis_dat(airquality, sort_type = FALSE)  #- en este otro dataset si q es útil
# visdat::vis_miss(airquality, cluster = TRUE)    #- se ve si se solapan los %nas

# library("dataMaid") #- https://github.com/ekstroem/dataMaid
# makeDataReport(df, output = "html")  # Produce data report
# makeCodebook(df, output = "html")    # Produce data Codebook
# check(df)

#- yo suelo mirar los datos así:
library(pjpv2020.01)
aa <- pjp_f_estadisticos_basicos(df)
bb <- pjp_f_unique_values(df)

# MANIPULANDO el df para OBTENER respuestas ------------------------------------------------------
# MANIPULANDO el df para OBTENER respuestas ------------------------------------------------------


#- 1) población de España en 2017
df %>% filter(year == 2017) %>% 
       summarise(NN = sum(pob_total))

#- 2) poblacion Total, H y M en 2016
df %>% filter(year == 2016) %>% 
       summarise(NN = sum(pob_total), NN_H = sum(pob_hombres), NN_M = sum(pob_mujeres))

df %>% filter(year == 2016) %>%  # tb se puede hacer de esta otra forma (y de muchas otras)
             select(pob_total, pob_hombres, pob_mujeres) %>% 
             summarise_all(sum)

#- 3) poblacion total en cada año
df %>% group_by(year) %>% 
            summarise(NN = sum(pob_total))

#- 4) incremento de la población
df %>% group_by(year) %>% 
             summarise(NN = sum(pob_total)) %>% 
             mutate(crec = NN - lag(NN))

#- 5) 10 municipios con mas población en 2015
df %>% filter(year == 2015) %>% 
             select(ine_muni, ine_muni.n, pob_total) %>% 
             arrange(desc(pob_total)) %>% 
             slice(1:10) 

#- 6) ¿cuantos municipios hay donde vivan más mujeres q hombres (2015)?
df %>% filter(year == 2015) %>% 
  mutate(mas_M = pob_mujeres - pob_hombres) %>% 
  mutate(Mas_M_1 = ifelse(mas_M > 0, 1, 0)) %>% 
  summarise(nn = sum(Mas_M_1))   #- ok, en 2015, habian 1946 municipios con mas Mujeres q hombres ¿Que % de los municipìos representa?

df %>% filter(year == 2015) %>% 
  mutate(mas_M = pob_mujeres - pob_hombres) %>%  #  hay un paso innecesario
  mutate(Mas_M_1 = ifelse(mas_M > 0, 1, 0)) %>% 
  summarise(MM = sum(Mas_M_1), pueblos = n(), percent = MM/pueblos) #- tan solo el 24% ¿donde estarán?

#- antes de dibujar donde estan los municipios con mas mujeres, vamos a ver en que CC.AA están
df %>% filter(year == 2015) %>% 
  group_by(ine_ccaa.n) %>% 
  mutate(Mas_M = ifelse(pob_mujeres > pob_hombres, 1, 0)) %>% 
  summarise(MM = sum(Mas_M), pueblos = n(), percent = MM/pueblos) %>% 
  arrange(desc(percent))       #- Galicia y Asturias

#- vamos a pintar los municipios q en 2015 tenían mas mujeres (en otro script)


#- hagamos un .Rmd con una tabla los municipios mas poblados en 2017


#- vamos a cargar otra tabla del INE para ver que nacionalidades son mayoritarias en¡tre los extranjeros residentes en España
