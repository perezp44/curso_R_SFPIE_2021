#- ejemplo gtrends: Visualising Google Trends results with R
#- https://github.com/PMassicotte/gtrendsR
#- https://davetang.org/muse/2018/12/31/visualising-google-trends-results-with-r/

library(tidyverse)
library(gtrendsR) #- devtools::install_github("PMassicotte/gtrendsR")

#- ayuda para el pkg gtrendsR
help(package = "gtrendsR")

categories <- categories #- se puede filtrar x categorías
countries <- countries   #- códigos de paises

#---- a ver quien es más famoso NV o BG
search_terms <- c("Nacho vegas", "Bad Gyal", "Nacho vegas", "Bad Gyal")
output_results <- gtrends(keyword = search_terms, geo = c("ES", "ES", "FR", "FR"), time = "today 12-m") 

plot(output_results)

#- como veis los resultados (como son complejos) nos los devuelve en una lista
names(output_results) 
zz <- output_results[[3]] #- #- en el elemento/slot nº 3 de la lista está el "interes por región"

#---------------------------
res <- gtrends(c("Nacho vegas", "Bad Gyal"), geo = "ES", time = "all")
names(res)
str(res)
zz <- res[[3]] %>% slice_max(hits, n = 5)  #- interés por región
zz <- res[[5]] %>% slice_max(hits, n = 5)  #- interés por ciudad
zz <- res[[1]]                             #- hits por dia
zz <- res[[7]]                             #- temas relacionados

#---------------------------
plot.gtrends.silent <- function(x, ...) {
  df <- x$interest_over_time
  df$date <- as.Date(df$date)
  df$hits <- if(typeof(df$hits) == 'character'){
    as.numeric(gsub('<','',df$hits))
  } else {
    df$hits
  }
  df$legend <- paste(df$keyword, " (", df$geo, ")", sep = "")
  p <- ggplot(df, aes_string(x = "date", y = "hits", color = "legend")) +
    geom_line() +
    xlab("Date") +
    ylab("Search hits") +
    ggtitle("Interest over time") +
    theme_bw() +
    theme(legend.title = element_blank())
  invisible(p)
}

my_plot <- plot.gtrends.silent(res)

my_plot + scale_x_date(date_breaks = "1 year", date_labels = "%Y") +  theme(legend.position = "none")

