# Hacer soniditos con R: https://github.com/brooke-watson/BRRR
# devtools::install_github("brooke-watson/BRRR")

library(BRRR)
f <- function(sound, sleep = 0.75) {
  Sys.sleep(sleep)
  BRRR::skrrrahh(sound = 29)
}

## WARNING: THIS WILL MAKE SOUND!!!!
for(i in 1:5) {
  f(i)
}
