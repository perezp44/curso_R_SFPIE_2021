#- ejemplo twitter collage: https://cran.r-project.org/web/packages/rtweet/vignettes/stream.html

library(rtweet)
library(tidyverse)
library(UpSetR)

#- un voluntario??
my_person <- ""



#- get a list of twitter accounts you want to compare
names_twitter <- c("bad_gyal_pussy", "NachoVegasTwit", "ivanferreiro", "c_tangana", "LuciaGil_Gil", "Avicii", "ElDrogasOficial", "gabrielleaplin", "stayhomas", "GhaliFoh", "bobsinclar", "thescript", "TravisBirds", "Residente", "Leiva_Oficial")

zz <- lookup_users(names_twitter)
zz_ver <- zz %>% select(user_id, screen_name, name, location, description, followers_count, friends_count, favourites_count, created_at, text, favorite_count, retweet_count, hashtags,  )


# queria bajarme los datos de las cuentas de sus seguidores, PERO, alguno de ellos tiene mas de 200.000 followers!!!
#- se puede pero ...
# followers <- map_df(zz, ~ get_followers(.x, n = 20000, retryonratelimit = TRUE) %>% mutate(account = .x))
#- asi que lo he hecho con los "friends"


friends <- map_df(names_twitter, ~ get_friends(.x, n = 20000, retryonratelimit = TRUE) %>% mutate(account = .x)) #------ BUSCA
#write_rds(friends, "./datos/friends_de_musicos_2.rds")
#friends <- read_rds("./datos/friends_de_musicos.rds")



#- vamos a bajarnos la informacion de los friends de nuestros músicos -----------
friends_data <- lookup_users(friends$user_id)   #---- BUSCA
#write_rds(friends_data, "./datos/friends_data_2.rds")
#friends_data <- read_rds("./datos/friends_data.rds")




#- vamos a hacer un gráfico útil con el pkg UpSetR -----------------------------------------------------
aRdent_followers <- unique(friends$user_id) #- get a de-duplicated list of all followers

# for each follower, get a binary indicator of whether they follow each tweeter or not and bind to one dataframe
binaries <- names_twitter %>%
  map_dfc(~ ifelse(aRdent_followers %in% filter(friends, account == .x)$user_id, 1, 0) %>%
            as.data.frame) # UpSetR doesn't like tibbles

names(binaries) <- names_twitter   #- # set column names

# plot the sets with UpSetR
upset(binaries, nsets = 7, main.bar.color = "SteelBlue", sets.bar.color = "DarkCyan",
      sets.x.label = "Gente a la que siguen nuestros políticos", text.scale = c(rep(1.4, 5), 1), order.by = "freq")


rm(binaries, aRdent_followers)  #- borro objetos

#--- Quienes son está gente a la que nuetros políticos siguen en twitter?? ------------------------------------------------------------
df_1 <- friends_data %>% select(user_id, screen_name, name, description, protected, followers_count, friends_count, profile_image_url, status_url)


#- Cómo hacemos para buscar a la gente que es seguida por los 4 políticos??
df_2 <- friends %>% group_by(user_id) %>% count() %>% filter(n >= 4) %>% arrange(desc(n))
df_influyente <- df_1 %>% filter(user_id %in% df_2$user_id)

rm(df_1, df_2, df_influyente, politicos)

#- lo hacemos de otra forma
friends_x <- friends %>% mutate(nnn = 1) %>% select(- user) %>%
  spread(account, nnn) %>%
  replace(is.na(.), 0) %>%
mutate(qq = rowSums(.[2:(length(names_twitter)+1)]))


#- busquemos a la interseccion entre BG y NV
cuenta_1 <- 3  #- 1 es BG, 2 es CT, 3 es IF
cuenta_2 <- 4  #- 4 es NV
friends_compartidos <- friends_x %>% filter(.[cuenta_1+1] == 1 & .[cuenta_2+1] == 1 )  #- 


zz_compartidos <- friends_data %>% 
          filter(user_id %in% friends_compartidos$user_id) %>% 
          select(user_id, screen_name, name, description, protected, followers_count, friends_count, profile_image_url, status_url)



