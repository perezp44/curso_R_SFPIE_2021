#- puedes hacer este pequeño tutorial de purrrr ----------------------
l1 <- list(a = c(1,2), b = c(2,3,4))
l1
l1[[1]]
seq_along(l1)

#- si queremos hallar la suma de cada elemento de la lista podemos hacerlo con un bucle: ---------------------------------------------------------

for (ii in 1:2 ) {
 aa <- sum( l1[[ii]] )  
 print(aa)
} 



for (in in seq_along(l1) ) {  #- es preferible seq_along: http://r.789695.n4.nabble.com/seq-along-and-rep-along-td4270377.html
aa <- sum( l1[[ii]] )  
  print(aa)
} 

#- o podemos usar la función map del paquete purrr ---------------------------------------------------------------------------------------------
library(purrr)

aa <- map(l1, sum)
aa <- map_chr(l1, sum)  #- el output es un vector
aa <- map_dfc(l1, sum)  #- el output es un df (x columnas)



#- tb puedes usar funciones anonimas (las 2 son equivalentes)
map(l1, ~ 2 + .x)             #- xq el punto
map(l1, function(x) 2 + x )




#- Calcular quantiles con map()   GOOD Si, para aplicar una funcion a una lista de variables
library(tidyverse) ; library(purrr)

aa <- mtcars %>%  select( . ,mpg, wt) %>%
  map( . , quantile, probs = c(0.10, 0.90), na.rm = TRUE) %>%
  as.data.frame(.) %>% `rownames<-`(c("10%", "90%"))

