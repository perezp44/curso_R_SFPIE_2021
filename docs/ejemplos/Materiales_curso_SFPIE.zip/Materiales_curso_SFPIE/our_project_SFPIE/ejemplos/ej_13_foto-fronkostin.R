#- https://github.com/aschinchon/travelling-salesman-portrait
# 
# install.packages("imager")
# install.packages("scales")
# install.packages("TSP")


library(imager)
library(TSP)
library(scales)
library(tidyverse)


# Download the image
urlfile = "http://ereaderbackgrounds.com/movies/bw/Frankenstein.jpg"

file = "./imagenes/frankenstein.jpg"
if (!file.exists(file)) download.file(urlfile, destfile = file, mode = 'wb')

# Load, convert to grayscale, filter image (to convert it to bw) and sample

#file <- "./imagenes/ejemplos/careto_pedro.png"  #- Error in grayscale(.) : Image should have three colour channels

#- como la imagen en PNG no valia, la pase a jpeg con los paquetes png y jpeg
# library(png)
# img <- readPNG(file)
# library("jpeg")
# writeJPEG(img, target = "./imagenes/ejemplos/careto_pedro.jpg", quality = 1)


#file1 <- "./imagenes/careto_pedro.jpg"  #- Error in grayscale(.) : Image should have three colour channels

load.image(file) %>% 
  grayscale() %>%
  threshold("45%") %>% 
  as.cimg() %>% 
  as.data.frame()  %>% 
  sample_n(8000, weight=(1-value)) %>% 
  select(x,y) -> data

# Compute distances and solve TSP (it may take a minute)
as.TSP(dist(data)) %>% 
  solve_TSP(method = "arbitrary_insertion") %>% 
  as.integer() -> solution

# Create a dataframe with the output of TSP
data.frame(id=solution) %>% 
  mutate(order=row_number()) -> order

# Rearrange the original points according the TSP output
data %>% 
  mutate(id=row_number()) %>% 
  inner_join(order, by="id") %>% arrange(order) %>% 
  select(x,y) -> data_to_plot

# A little bit of ggplot to plot results
ggplot(data_to_plot, aes(x,y)) +
  geom_path() +
  scale_y_continuous(trans=reverse_trans()) +
  coord_fixed() +
  theme_void()

# Do you like the result? Save it! (Change the filename if you want)
# ggsave("./imagenes/ejemplos/frankyTSP.png", dpi=600, width = 4, height = 5)
