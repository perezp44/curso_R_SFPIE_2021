#- datos de muertes semanales de Eurostat
#- ej_eurostat-momo: https://medium.com/responsibleml/plotting-the-excessive-number-of-deaths-in-2020-by-age-with-the-eurostat-package-5cabbd51ebdd
#- pirámides de población: https://kjhealy.github.io/uscenpops/

library(tidyverse)
library(eurostat)
library(pjpv2020.01)  #- remotes::install_github("perezp44/pjpv2020.01")

aa <- search_eurostat("Population", type = "all") #- busco datos relacionados con población

#- primero me bajo la tabla "demo_r_d2jan": Population on 1 January by age, sex and NUTS 2 region"
my_table <- "demo_r_d2jan"         #- "Population on 1 January by age, sex and NUTS 2 region"
label_eurostat_tables(my_table)    #- gives information about the table

#------------------ dowloading the selected data with get_eurostat()
df <- get_eurostat(my_table, time_format = 'raw', keepFlags = TRUE)       #- dowloads the table from Eurostat API
#df_l <- label_eurostat(df, fix_duplicated = TRUE)                        #- gives labels for the variables
df_names <- names(df)
df <- label_eurostat(df, code = df_names, fix_duplicated = TRUE)
rm(aa,  df_names, my_table)
#zz <- df %>% filter(stringr::str_starts(geo, "ES")) %>% filter(time == 2019) %>% filter(age == "Y1")

df_pop <- df  #- AQUI guardo los datos de población (tabla demo_r_d2jan)
df_bb <- pjpv2020.01::pjp_f_unique_values(df_pop, truncate = TRUE, nn_truncate = 200)
df_pop <- df_pop %>% select(-c(unit, unit_code, sex_code, flags, time_code, values_code))
rm(df, df_bb)
rio::export(df_pop, "./datos/df_pop.rds")

#- AHORA me bajo las muertes ---------------------------------------------------
#- AHORA me bajo las muertes ---------------------------------------------------

aa <- search_eurostat("Deaths", type = "all") #- busco datos relacionados con muertes

#- me bajo la tabla "demo_r_mwk_10": "Deaths by week, sex and 10-year age group"
my_table <- "demo_r_mwk_10"         #- "Deaths by week, sex and 10-year age group" 
label_eurostat_tables(my_table)     #- gives information about the table

#------------------ dowloading the selected data with get_eurostat()
df <- get_eurostat(my_table, time_format = 'raw', keepFlags = TRUE)       #- dowloads the table from Eurostat API
#df_l <- label_eurostat(df, fix_duplicated = TRUE)                        #- gives labels for the variables
df_names <- names(df)
df <- label_eurostat(df, code = df_names, fix_duplicated = TRUE)
rm(aa, df_l, df_names, my_table)
#zz <- df %>% filter(stringr::str_starts(geo, "ES")) %>% filter(time == 2019) %>% filter(age == "Y1")

df_mort <- df  #- AQUI tengo Deaths by week, sex and 10-year age group
df_bb <- pjpv2020.01::pjp_f_unique_values(df_mort, truncate = TRUE, nn_truncate = 200)
df_mort <- df_mort %>% select(-c(unit, unit_code, sex_code, flags, time_code, values_code))
rm(df, df_bb)
rio::export(df_mort, "./datos/df_mort.rds")

#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#- como bajar los datos de Eurostat cuesta un poquitín, he guardado los datos y puedo empezar el análisis desde aquí
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
rm(list = ls())  #- limpio el Global

library(tidyverse)
library(eurostat)
library(pjpv2020.01)  #- remotes::install_github("perezp44/pjpv2020.01")

df_pop <- rio::import("./datos/df_pop.rds")
df_mort <- rio::import("./datos/df_mort.rds")

#-- ahora se trata de limpiar y fusionar los 2 df's
#-- Ahora se trata de quedarme solo con lo que me interesa y fusionar ----------
paises_mort <- df_mort %>% distinct(geo_code) %>% pull   #- lista de países en el df de muertes

df_pop <- df_pop %>% filter(geo_code %in% paises_mort)   #- en df_pop me quedo solo con los países q tienen datos de muertes (que estan en el df df_mort)


#----------------------------------------- JUNTAR los 2 df's -------------------
#----------------------------------------- JUNTAR los 2 df's -------------------
#- df_pop y df_mort

rm(list= ls()[!(ls() %in% c('df_pop','df_mort'))]) #- borro todo excepto


#- PRIMERO arreglo os datos de muertes (df_mort) -------------------------------
#- PRIMERO arreglo os datos de muertes (df_mort) -------------------------------

#- para arreglarlo tenemos que cotillear un poco sobre las v. de df_pop
names(df_pop)
names(df_mort)
df_mort_bb <- pjpv2020.01::pjp_f_unique_values(df_mort, truncate = TRUE, nn_truncate = 200)
df_mort_ages <- df_mort %>% distinct(age_code, age)
#- he visto q tengo que quitar algunas categorias de edad
df_mort <- df_mort %>%  #- quito algunas categorias de edad
  filter(age_code != "TOTAL") %>% 
  filter(age_code != "UNK") %>% 
  filter(age_code != "Y_GE80")

#- recodifico la variable age_code
df_mort <- df_mort %>% mutate(age_code = as_factor(case_when(
  age_code == "Y_LT10" ~ "[  <10  ]",
  age_code == "Y10-19" ~ "[10 - 19]",
  age_code == "Y20-29" ~ "[20 - 29]",
  age_code == "Y30-39" ~ "[30 - 39]",
  age_code == "Y40-49" ~ "[40 - 49]",
  age_code == "Y50-59" ~ "[50 - 59]",
  age_code == "Y60-69" ~ "[60 - 69]",
  age_code == "Y70-79" ~ "[70 - 79]",
  age_code == "Y80-89" ~ "[80 - 89]",
  age_code == "Y_GE90" ~ "[  >90  ]",
    TRUE ~ "feo")))

#- ordeno los niveles de los factores [ <10 ] quiero que sea el primer level
df_mort <- df_mort %>% mutate(age_code = forcats::fct_relevel(age_code, "[  <10  ]"))

df_mort <- df_mort %>% select(-c(age, flags_code)) #- quito 2 variables

#- arreglo un poco más las variables
df_mort <- df_mort %>% rename(week = time)
df_mort <- df_mort %>% rename(values_mort = values)
df_mort <- df_mort %>% mutate(year = stringr::str_extract(week, "...."))  #- extraigo el año
df_mort <- df_mort %>% mutate(week = stringr::str_extract(week, "..$"))  #- extraigo el año

#- reordeno las variables
df_mort <- df_mort %>% select(age_code, geo_code, geo, sex, year, week, values_mort )

#zz <- df_mort %>% filter(geo == "Sweden", year == "2020")

#- AHORA arreglo la población (df_pop) -----------------------------------------
#- AHORA arreglo la población (df_pop) -----------------------------------------

df_bb <- pjpv2020.01::pjp_f_unique_values(df_pop, truncate = TRUE, nn_truncate = 200)

anyos_pob <- df_pop %>% distinct(age, age_code)   #- los de cero años son Y_LT1, los Y_OPN son mas de 100, UNK son unkwon

df_pop <- df_pop %>% filter(age != "Total") %>% filter(age_code != "UNK")   #- quito el Total y los q no se sabe la edad (UNKnown)

#- arreglo un poco los datos
df_pop <- df_pop %>% mutate(age = ifelse(age_code == "Y_OPEN", "100", age))
df_pop <- df_pop %>% mutate(age = ifelse(age_code == "Y_LT1", "0", age))
df_pop <- df_pop %>% mutate(age = stringr::str_remove(age, " years"))
df_pop <- df_pop %>% mutate(age = stringr::str_remove(age, " year"))
df_pop <- df_pop %>% mutate(age = as.integer(age))
df_pop <- df_pop %>% select(-age_code)

#- Ahora he de agrupar grupos de edad
df_pop <- df_pop %>% mutate(age = as_factor(case_when(
  between(age, 0, 9)     ~ "[  <10  ]",
  between(age, 10, 19)   ~ "[10 - 19]",
  between(age, 20, 29)   ~ "[20 - 29]",
  between(age, 30, 39)   ~ "[30 - 39]",
  between(age, 40, 49)   ~ "[40 - 49]",
  between(age, 50, 59)   ~ "[50 - 59]",
  between(age, 60, 69)   ~ "[60 - 69]",
  between(age, 70, 79)   ~ "[70 - 79]",
  between(age, 80, 89)   ~ "[80 - 89]",
  between(age, 90, 100)  ~ "[  >90  ]",
  TRUE ~ "feo")))
df_pop <- df_pop %>% mutate(age = forcats::fct_relevel(age, "[  <10  ]"))

#- sumo los casos de cada categoría (de cada grupo de edad)
df_pop <- df_pop %>% group_by(geo, geo_code, time, sex, age) %>% summarise(values = sum(values)) 
#- arreglo
df_pop <- df_pop %>% rename(age_code = age) %>% rename(values_pob = values) 
df_pop <- df_pop %>% rename(year = time) 
df_pop <- df_pop %>% select(age_code, geo_code, geo, sex, year, values_pob )

#- tenemos el Pb de que en los datos de población solo hay hasta 2019
#- Lo que voy a hacer es usar los datos de 2019 para 2019, pero tb para 2020
df_pop_2019 <- df_pop %>% filter(year == 2019)
df_pop_2019 <- df_pop_2019 %>% mutate(year = "2020")
df_pop <- bind_rows(df_pop, df_pop_2019)

#- AHORa tenemos que juntar los 2 df's junto -----------------------------------
#- AHORa tenemos que juntar los 2 df's junto -----------------------------------

names(df_pop)
names(df_mort)

df_A <- left_join(df_mort, df_pop, by = c("age_code" = "age_code", "geo_code" = "geo_code", "geo" = "geo", "sex" = "sex", "year" = "year"))

rm(list= ls()[!(ls() %in% c('df_pop','df_mort', "df_A"))])

#- Calculo PORCENTAJES de muertes (por 100.000 habitantes en cada tramo de edad)
names(df_A)

df_A <- df_A %>% group_by(age_code, geo_code, geo, sex, week) %>% 
  mutate(percent = (values_mort/values_pob)*100) %>% 
  mutate(percent_x = (values_mort/values_pob)*100000)


#- vamos a ver los datos de 2020
df_A_2020  <- df_A %>% filter(year == "2020") %>% arrange(desc(percent))

#- los datos de 2020 y 2019 para ESP
df_A_esp_19_20  <- df_A %>% filter(year %in% c("2020", "2019")) %>% 
                            filter(geo == "Spain") %>% arrange(desc(percent))

#- BUENO tenemos los datos arreglados (ha costado un poquitín) ahora se trataría de intentar ver lo que dicen los datos



