#- https://statisticaloddsandends.wordpress.com/2020/08/06/basic-manipulation-of-gif-frames-with-magick/
#- pkg para manipular imagenes
library(magick) 

#- en esta ruta hay un gif
img_path <- paste0("https://media3.giphy.com/media/3o72F9VC4WjFDCPTag/",
                   "giphy.gif?cid=ecf05e470ceb6cd8542e8c243d0e0a2282c3390e5c",
                   "72fd17&rid=giphy.gif")

img <- magick::image_read(img_path)

img #- podemos ver el gif

print(img) #- el gif tiene 44 frames

#- manipulamos el gif y repetimos algun frame
img[c(1:44, rep(c(rep(44, times = 5), 43:30, 
                  rep(30, times = 5), 31:43), 
                times = 2))]
#- otros efectos
img[c(15:30, rep(31:32, each = 33))]

#- leemos una imagen, el logo de R
logo <- image_read("https://jeroen.github.io/images/Rlogo.png") %>%
  image_resize("480x266!")

#- insertamos el logo en el gif
img[25] <- logo
img

#- ponemos dentro del gif a NV
NV <- image_read("./imagenes/NV.jpg")
img[22] <- NV
img[c(15:30, rep(21:23, each = 4))] #- metemos a NV dentro
