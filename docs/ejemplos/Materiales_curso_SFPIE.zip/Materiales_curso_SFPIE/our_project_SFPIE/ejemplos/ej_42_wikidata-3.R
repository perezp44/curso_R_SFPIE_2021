#- Wikidata mola!!!  Wikidata, hay que conocerla más!!

#- video de 7 minutos: https://www.youtube.com/watch?v=24DOvuZWaD0
#- video más largito: https://commons.wikimedia.org/wiki/File:Querying_Wikidata_with_SPARQL_for_Absolute_Beginners.webm


#- wikidata: https://www.wikidata.org/wiki/Wikidata:Main_Page
#- wikidata Queries: https://query.wikidata.org/

#- ejemplo de queries: cronologia de sondas espaciales

https://query.wikidata.org/#%23Cronolog%C3%ADa%20de%20sondas%20espaciales%0A%23defaultView%3ATimeline%0ASELECT%20%3Fitem%20%3FitemLabel%20%3Flaunchdate%20%28SAMPLE%28%3Fimage%29%20AS%20%3Fimage%29%0AWHERE%0A%7B%0A%09%3Fitem%20wdt%3AP31%20wd%3AQ26529%20.%0A%20%20%20%20%3Fitem%20wdt%3AP619%20%3Flaunchdate%20.%0A%09SERVICE%20wikibase%3Alabel%20%7B%20bd%3AserviceParam%20wikibase%3Alanguage%20%22%5BAUTO_LANGUAGE%5D%2Cen%22%20%7D%0A%20%20%20%20OPTIONAL%20%7B%20%3Fitem%20wdt%3AP18%20%3Fimage%20%7D%0A%7D%0AGROUP%20BY%20%3Fitem%20%3FitemLabel%20%3Flaunchdate

#- ejemplo de queries: Tributaries of all Italian rivers known to @wikidata as directed graphs. Highlighting: Tiber (Q13712, left) and Po (Q643, right): http://tinyurl.com/yc8mmyph

https://query.wikidata.org/#SELECT%20%28COUNT%28DISTINCT%28%3Fpolitician%29%29%20AS%20%3Fc%29%20%3Fcountry_of_citizenshipLabel%20WHERE%20%7B%0A%20%20SERVICE%20wikibase%3Alabel%20%7B%20bd%3AserviceParam%20wikibase%3Alanguage%20%22%5BAUTO_LANGUAGE%5D%2Cen%22.%20%7D%0A%20%20%3Fpolitician%20wdt%3AP31%20wd%3AQ5.%0A%20%20%3Fpolitician%20wdt%3AP2002%20%3FTwitter_username.%0A%20%20%3Fpolitician%20wdt%3AP106%20wd%3AQ82955.%0A%20%20OPTIONAL%20%7B%20%3Fpolitician%20wdt%3AP27%20%3Fcountry_of_citizenship.%20%7D%0A%7D%0AGROUP%20BY%20%3Fcountry_of_citizenshipLabel%0AORDER%20BY%20DESC%28%3Fc%29


#- vi esta consulta en Twitter:  https://twitter.com/TheShubhanshu/status/1109624935662669824
#- asi q la modifique

#- vamos a hacer una consulta a wikidata: http://tinyurl.com/yy6l8u96
SELECT ?politician ?politicianLabel ?country_of_citizenshipLabel ?Twitter_username ?miembro_del_partido_pol_ticoLabel WHERE {
    SERVICE wikibase:label { bd:serviceParam wikibase:language "[AUTO_LANGUAGE],en". }
    ?politician wdt:P31 wd:Q5;
    wdt:P2002 ?Twitter_username;
    wdt:P106 wd:Q82955.
    OPTIONAL { ?politician wdt:P27 ?country_of_citizenship. }
    OPTIONAL { ?politician wdt:P102 ?miembro_del_partido_pol_tico. }
}

#- hice la consulta desde R, pero ya no funciona, así que voy a importar los datos de la consulta que hice el año pasado
library(tidyverse)

df_1 <- rio::import("./datos/sparql_politics.rds")
aa_1 <- df_1 %>% count(country_of_citizenshipLabel) %>% arrange(desc(n))
spanish_politicians_1 <- df_1 %>% filter(country_of_citizenshipLabel == "\"Spain\"@en")
aa_1 <- spanish_politicians_1 %>% count(miembro_del_partido_pol_ticoLabel) %>% arrange(desc(n))


#- el 12 de Diciembre de 2019 volví a  hacer la consulta
df_2 <- read_rds("./datos/sparql_politics_2.rds")
aa_2 <- df_2 %>% count(country_of_citizenshipLabel) %>% arrange(desc(n))
spanish_politicians_2 <- df_2 %>% filter(country_of_citizenshipLabel == "España")
aa_2 <- spanish_politicians_2 %>% count(miembro_del_partido_pol_ticoLabel) %>% arrange(desc(n))


#- quienes son los nuevos politicos españoles con Twitter
#- cuantas rows tiene mas ahora
nrow(spanish_politicians_2) - nrow(spanish_politicians_1) #- 573 rows de diferencia, pero no es tan fácil
#- no es tan fácil
df_3 <- setdiff(spanish_politicians_2, spanish_politicians_1)
names(spanish_politicians_1)


xx_1 <- spanish_politicians_1 %>% select(Twitter_username) %>% distinct() %>% pull()
xx_2 <- spanish_politicians_2 %>% select(Twitter_username) %>% distinct() %>% pull()

polit_q_si_estaban  <- spanish_politicians_2 %>% filter(Twitter_username %in% xx_1)      #- 1365
polit_q_no_estaban  <- spanish_politicians_2 %>% filter(!(Twitter_username %in% xx_1))   #- 583
polit_dados_de_baja <- spanish_politicians_1 %>% filter(!(Twitter_username %in% xx_2))   #- 46: izaskunbilbaob vs. IzaskunBilbaoB




#------------- query de los NOBELES
#- Los datos de Tidy Tuesday tenian los datos hasta 2016, ¿y los de 2017, 2018 y 2019?
#- hagamos una querie a Wikidata: https://query.wikidata.org/
#- puedes probar con ejemplos:

SELECT DISTINCT ?person ?personLabel ?awardLabel ?year ?fecha_de_nacimiento ?fecha_de_fallecimiento ?_image ?ocupaci_n ?ocupaci_nLabel WHERE {
    ?person p:P166 ?statement.
    ?statement ps:P166 ?award.
    ?award wdt:P31 wd:Q7191.
    OPTIONAL {
        ?statement pq:P585 ?date.
        BIND(YEAR(?date) AS ?year)
    }
    SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
    OPTIONAL { ?person wdt:P569 ?fecha_de_nacimiento. }
    OPTIONAL { ?person wdt:P570 ?fecha_de_fallecimiento. }
    OPTIONAL { ?person wdt:P18 ?_image. }
    OPTIONAL { ?person wdt:P101 ?ocupaci_n. }
}
ORDER BY DESC (?year) (?awardLabel)



