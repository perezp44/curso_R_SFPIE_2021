#- script para seguir las slides de importacion de datos

#- slide nº 6 ------------------------------------------------------------------

#- cuanto iniciamos R se cargan automaticamente un grupo de paquetes (R-base)
print(.packages()) #- [🌶]imprimimos los nombres de los "currently attached packages"

#- en uno de esos paquetes hay un conjunto de datos llamado "iris"
iris          #- llamamos a "iris"
str(iris)     #- qué es iris?
find("iris")  #- [🌶] ¿donde estaba iris?

my_iris <- iris  #- "hacemos una copia" de iris
find("my_iris")  #- ¿donde está my_iris?

iris <- iris     #- ???
find("iris")     #- ¿donde está ahora iris?



#- slide nº 7 ------------------------------------------------------------------

#- en el pkg palmerpenguins hay 2 conjuntos de datos
library(palmerpenguins) #- install.packages("palmerpenguins")

#- ya podemos usar los datos de penguins xq hemos cargado (attach) el paquete en memoria de R
penguins
my_penguins <- penguins

#- quiero tb hablaros de la siguiente expresión 
#- es importante acostumbrarse a ella [ 🌟 ]
palmerpenguins::penguins

#- slide nº 9 ------------------------------------------------------------------

#- Solución--
rm(list = ls()) #- antes vamos a limpiar el Global env.

la_direccion <- "https://raw.githubusercontent.com/perezp44/iris_data/master/data/iris.csv"

rio::import(la_direccion)    #- ¿qué ha pasado???

iris <- rio::import(la_direccion)  #- y ahora ¿qué ha pasado?

#- Solución (extended)--
rm(list = ls()) #- antes vamos a limpiar el Global env.

la_direccion <- "https://raw.githubusercontent.com/perezp44/iris_data/master/data/iris.csv"

iris_1 <-  rio::import(la_direccion)  #- como un data.frame

iris_2 <- rio::import(la_direccion, setclass = "tibble")  #- como tibble

iris_3 <- tibble::as_tibble(iris_1) #- convertimos df_1 a tibble


#- slide nº 11 -----------------------------------------------------------------

#- Solución 1 --
rm(list = ls())  #- [🌶] antes vamos a limpiar el Global env.

my_iris <- iris

rio::export(my_iris, "my_iris.csv")             #- sin los nombres de los argumentos
rio::export(x = my_iris, file = "my_iris.csv")  #- CON los nombres de los argumentos
#- IMPORTANTE: ¿Donde hemos guardado my_iris? [ 🌟 ]

#- Solución 2 (Ahora tenemos que guardar my_iris en la subcarpeta "pruebas")

fs::dir_create("pruebas")   #- [🌶] creo el subdirectorio

rio::export(my_iris, "./pruebas/my_iris.csv")

#- Perfecto, pero es mejor construir la ruta utilizando el pkg "here". [ 🌟 ]
la_ruta <- here::here("pruebas", "my_iris.csv")

rio::export(my_iris, la_ruta)

rio::export(my_iris, here::here("pruebas", "my_iris.csv"))


#- slide nº 12 -----------------------------------------------------------------
#- Solución 1 --
rio::export(iris, here::here("pruebas", "iris.csv"))
rio::export(iris, here::here("pruebas", "iris.xlsx"))
rio::export(iris, here::here("pruebas", "iris.sav"))
#- Solución 2 --
rio::export(palmerpenguins::penguins, here::here("pruebas", "pinguinos.csv"))
rio::export(palmerpenguins::penguins, here::here("pruebas", "pinguinos.xlsx"))
rio::export(palmerpenguins::penguins, here::here("pruebas", "pinguinos.dta"))


#- slide nº 14 -----------------------------------------------------------------

#- Solución 1--
rm(list = ls())

iris_1 <- rio::import(here::here("pruebas", "iris.csv"))

iris_2 <- rio::import(here::here("pruebas", "iris.xlsx"))

#- Solución 2-- (tendrás que hacerlo tú)




#- Slide nº 15  [🌶]  ----------------------------------------------------------

#- en esta url hay un fichero de datos en formato .csv
my_url <- "https://raw.githubusercontent.com/perezp44/iris_data/master/data/iris.csv"

#- descargamos y guardamos los datos en nuestro PC
download.file(url = my_url, 
              destfile = here::here("pruebas", "iris_descargado.csv"))
#- importamos los datos en R
aa <- rio::import(my_url)


#- BONUS (slides nº 17 a 19) --------------------------------------------------------

#- Bonus 1: le añadimos un libro mas al archivo "./pruebas/iris.xlsx"
rio::export(x = iris, 
            file = here::here("pruebas", "iris.xlsx"), 
            which = "iris_2")

#- Bonus 2: (!!) exportar 2 df's en un único archivo .xlsx
rio::export(x = list(iris = iris, pinguinos = palmerpenguins::penguins), 
            file = here::here("pruebas", "my_iris_pinguinos.xlsx"))

#- Bonus 3: (!!) importar una hoja/libro especifica de un archivo .xlsx
iris_1 <- rio::import(here::here("pruebas", "my_iris_pinguinos.xlsx"))  #- solo importa el primer libro
pinguinos_1 <- rio::import(here::here("pruebas", "my_iris_pinguinos.xlsx"), 
                           sheet = 2)
pinguinos_2 <- rio::import(here::here("pruebas", "my_iris_pinguinos.xlsx"), 
                           sheet = "pinguinos")

#- Bonus 4: (!!!!) importamos todos los libros de un archivo `.xlsx`
library(readxl) #- necesitamos readxl::excel_sheet

my_dfs_list <- lapply(excel_sheets(here::here("pruebas", "my_iris_pinguinos.xlsx")), 
                      read_excel,
                      path = here::here("pruebas", "my_iris_pinguinos.xlsx"))

#- Bonus 5: (!!!!!!) importamos todos archivos de datos de la carpeta pruebas
library(purrr)  
my_carpeta <- here::here("pruebas")

lista_de_archivos <- list.files(my_carpeta)  #- Ok con base ...
lista_de_archivos <- fs::dir_ls(my_carpeta)  #- pero mejor con el pkg "fs"

my_dfs_list_2 <- map(lista_de_archivos, rio::import)


#- slide nº 20 -----------------------------------------------------------------
#- vamos a limpiar el Rproject: vamos a borrar los archivos q hemos creado:
  
list.files("./pruebas")     #- listado de archivos en la carpeta "./pruebas"

file.remove("./pruebas/pinguinos.dta")   #- borramos un archivo

#- borramos todos los archivos de ./pruebas/
file.remove(file.path("./pruebas", list.files("./pruebas"))) 

#- borramos toda la carpeta con el pkg fs
fs::dir_delete("pruebas")


#- slide nº 23 -----------------------------------------------------------------
#- exportando daros a formato  .Rda o .Rdata
fs::dir_create("pruebas")   #- creo la carpeta "pruebas" (otra vez)

save(mtcars, iris,  file = here::here("pruebas", "mtcars_and_iris.RData"))

#- importando datos en .Rda
load(here::here("pruebas", "mtcars_and_iris.RData"))
     
#- slide nº 24 -----------------------------------------------------------------
#- exportando daros a formato  .rds
saveRDS(iris, here::here("pruebas", "iris_1.rds"))          #- con base-R
readr::write_rds(iris, here::here("pruebas", "iris_2.rds")) #- con pkg "readr"
rio::export(iris, here::here("pruebas", "iris_3.rds"))

#- importando daros en formato  .rds
my_iris_1 <- readRDS(here::here("pruebas", "iris_3.rds"))  #- con R-base
my_iris_1 <-readr::read_rds(here::here("pruebas", "iris_3.rds")) #- tidyverse
my_iris_2 <- rio::import(here::here("pruebas", "iris_3.rds"))

#- slide nº 26 -----------------------------------------------------------------
#- accediendo a la API de Eurostat
library(eurostat) # install.packages("eurostat")
df <- get_eurostat("cult_emp_sex", time_format = 'raw', keepFlags = T)       #- bajamos los datos de la tabla "cult_emp_sex": empleo cultural por genero"

#- mas de Eurostat --
# install.packages("eurostat")
library(eurostat)

#- podemos buscar un  "tema" con la f. search_eurostat()
aa <- search_eurostat("employment", type = "all") 

#- elegimos una tabla de Eurostat
my_table <- "hlth_silc_17"   #- elegimos una tabla; por ejemplo "hlth_silc_17": "Healthy life expectancy based on self-perceived health"
label_eurostat_tables(my_table) #- da informacion sobre la Base de datos q estas buscando

#-  descargamos los datos con get_eurostat()
df <- get_eurostat(my_table, time_format = "raw", keepFlags = TRUE )   #- bajamos los datos de una tabla
df_l <- label_eurostat(df)        #- pone labels: mas legible, menos fácil de programar


#- slide nº 30 -----------------------------------------------------------------
#- Webscrapping Wikipedia

library(rvest)
library(tidyverse)

my_url <- "https://es.wikipedia.org/wiki/Pandemia_de_enfermedad_por_coronavirus_de_2020_en_Espa%C3%B1a"


content <- read_html(my_url)
body_table <- content %>% html_nodes('body')  %>%
  html_nodes('table') %>%
  html_table(dec = ",", fill = TRUE) 

#- la página web tiene 10 tablas
tabla_6 <- body_table[[6]]  
tabla_7 <- body_table[[7]]  


#- CASO (slide nº 32) ----------------------------------------------------------
download.file()
#- Solución 1 (con rio) --
rm(list = ls())  #- antes vamos a limpiar el Global env.
my_url <- "https://www.ine.es/daco/daco42/codmun/codmun20/20codmun.xlsx"
download.file(my_url, here::here("pruebas", "ine_rel_muni.xlsx"))

df_1 <- rio::import(my_url) #- q pb tenemos?

#- Solución 3 (con readxl) --
df_2 <- readxl::read_xlsx(my_url, skip = 1)  #- no funciona. solo lee del PC
df_2 <- readxl::read_xlsx(here::here("pruebas", "ine_rel_muni.xlsx"), skip = 1)


#- Un poco más profesional -----------------------------------------------------
#- script para bajar la relación de municipios INE a 1 de enero de 2021 
url_descarga <- "https://www.ine.es/daco/daco42/codmun/diccionario21.xlsx"
nombre_fichero <- "diccionario21.xlsx"
fs::dir_create("tmp")   #- creo un directorio temporal
my_ruta <- here::here("tmp", nombre_fichero) #- ruta para guardar el fichero
curl::curl_download(url = url_descarga, destfile = my_ruta)

#- importo el fichero
df <- readxl::read_xlsx(path = my_ruta, skip = 1)
#- la verdad es que skip = 1 también hubiese funcionado con el paquete `rio` 
#- ya que `rio` llama a `readxl`

#- arreglo los datos
library(tidyverse)
df <- df %>% 
  mutate(ine_muni = paste0(CPRO, CMUN)) %>% 
  mutate(year = "2021") %>%          #- !! cómo lo guardaría?
  mutate(year = as.numeric(year)) %>% 
  rename(ine_muni.n = NOMBRE) %>% 
  rename(ine_prov = CPRO) %>% 
  select(ine_muni, ine_muni.n, ine_prov, year) 
str(df)


#- exporto el archivo(me lo guardo)
readr::write_csv(df, file = here::here("tmp", "my_relacion_muni_2021.csv"))

#- Contamos el nº de muni x provincias
df_muni <- df %>% group_by(ine_prov) %>% 
                  summarise(numero_muni = n())

df_muni <- df %>% count(ine_prov)

#- Si quisiéramos saber el nombre de las provincias ... tenemos que cargar un nuevo fichero con esa información:
codigos_prov <- pjpv.datos.01::pob_prov_1996_2020 %>% filter(year == 2020)
str(codigos_prov)              

#- fusiono los 2 ficheros (lo veremos!!)
df_ok <- left_join(df_muni, codigos_prov)

#- Borro la carpeta tmp para dejar el Rproject limpio
fs::dir_delete("tmp")  #- [🌶] borro el directorio temporal
